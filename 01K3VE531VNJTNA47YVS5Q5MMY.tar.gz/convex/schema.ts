import { defineSchema } from "convex/server";

export default defineSchema({});
