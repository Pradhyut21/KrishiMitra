import { useState } from "react";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Satellite, Smartphone, TrendingUp, Users, MapPin, AlertTriangle, CheckCircle, Clock } from "lucide-react";
import Hero from "./_components/Hero.tsx";
import Features from "./_components/Features.tsx";
import Dashboard from "./_components/Dashboard.tsx";
import Stats from "./_components/Stats.tsx";
import Testimonials from "./_components/Testimonials.tsx";
import Footer from "./_components/Footer.tsx";

export default function Index() {
  const [activeTab, setActiveTab] = useState("dashboard");

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white">
      <Hero />
      <Stats />
      
      <section className="py-16 px-4 max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            KrishiMitra Platform
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the power of AI-driven precision agriculture designed specifically for India's small farmers
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 max-w-2xl mx-auto mb-8">
            <TabsTrigger value="dashboard" className="flex items-center gap-2">
              <TrendingUp className="size-4" />
              Crop Health
            </TabsTrigger>
            <TabsTrigger value="satellite" className="flex items-center gap-2">
              <Satellite className="size-4" />
              Satellite View
            </TabsTrigger>
            <TabsTrigger value="alerts" className="flex items-center gap-2">
              <AlertTriangle className="size-4" />
              Smart Alerts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <Dashboard />
          </TabsContent>

          <TabsContent value="satellite">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Satellite className="size-5 text-blue-600" />
                  Real-Time Satellite Analysis
                </CardTitle>
                <CardDescription>
                  AI-powered crop health monitoring using satellite imagery from multiple sources
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Multi-Spectral Analysis</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <span className="font-medium">NDVI (Vegetation Health)</span>
                        <Badge variant="secondary" className="bg-green-100 text-green-800">0.87 - Excellent</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                        <span className="font-medium">NDWI (Water Stress)</span>
                        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">0.42 - Moderate</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <span className="font-medium">EVI (Chlorophyll)</span>
                        <Badge variant="secondary" className="bg-blue-100 text-blue-800">0.65 - Good</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="font-semibold text-lg">Disease Detection</h3>
                    <div className="p-4 border rounded-lg bg-gradient-to-r from-green-50 to-emerald-50">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle className="size-5 text-green-600" />
                        <span className="font-medium text-green-800">Crop Status: Healthy</span>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">
                        AI confidence: 94.7% | Last scan: 2 hours ago
                      </p>
                      <div className="text-sm space-y-1">
                        <div>• No disease patterns detected</div>
                        <div>• Pest risk: Low (12%)</div>
                        <div>• Yield prediction: 4.2 tons/hectare</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg">
                  <h3 className="font-semibold text-lg mb-3">Satellite Data Sources</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">Sentinel-2</div>
                      <div className="text-sm text-muted-foreground">10m Resolution</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">ResourceSAT</div>
                      <div className="text-sm text-muted-foreground">ISRO Data</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-600">Sentinel-1</div>
                      <div className="text-sm text-muted-foreground">SAR Data</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">Weather</div>
                      <div className="text-sm text-muted-foreground">IMD Grid</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alerts">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="size-5 text-amber-600" />
                  Smart Alert System
                </CardTitle>
                <CardDescription>
                  Receive timely notifications in your preferred language via WhatsApp
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-4">
                  <div className="flex items-start gap-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                    <AlertTriangle className="size-5 text-red-600 mt-0.5" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-red-800">High Priority Alert</span>
                        <Badge className="bg-red-100 text-red-800">2 hours ago</Badge>
                      </div>
                      <p className="text-sm text-red-700 mb-2">
                        Early aphid infestation detected in Block C-2. Immediate action recommended.
                      </p>
                      <div className="text-sm text-muted-foreground">
                        Hindi: ब्लॉक सी-2 में माहू का प्रारंभिक संक्रमण। तुरंत कार्रवाई आवश्यक।
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <Clock className="size-5 text-yellow-600 mt-0.5" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-yellow-800">Scheduled Alert</span>
                        <Badge className="bg-yellow-100 text-yellow-800">Tomorrow</Badge>
                      </div>
                      <p className="text-sm text-yellow-700 mb-2">
                        Optimal fertilizer application window: March 15-17. Weather favorable.
                      </p>
                      <div className="text-sm text-muted-foreground">
                        Punjabi: ਖਾਦ ਪਾਉਣ ਦਾ ਚੰਗਾ ਸਮਾਂ: 15-17 ਮਾਰਚ। ਮੌਸਮ ਅਨੁਕੂਲ।
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <CheckCircle className="size-5 text-green-600 mt-0.5" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-green-800">Success Update</span>
                        <Badge className="bg-green-100 text-green-800">1 day ago</Badge>
                      </div>
                      <p className="text-sm text-green-700 mb-2">
                        Treatment successful! Crop health improved by 23% after recommended intervention.
                      </p>
                      <div className="text-sm text-muted-foreground">
                        Tamil: சிகிச்சை வெற்றிகரமானது! பரிந்துரைக்கப்பட்ட தலையீட்டிற்குப் பிறகு பயிர் ஆரோக்கியம் 23% மேம்பட்டது।
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-lg">
                  <h3 className="font-semibold text-lg mb-4">WhatsApp Integration Features</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Smartphone className="size-4 text-green-600" />
                        <span className="text-sm font-medium">Voice commands in local languages</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="size-4 text-blue-600" />
                        <span className="text-sm font-medium">GPS-accurate field mapping</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="size-4 text-purple-600" />
                        <span className="text-sm font-medium">Community disease alerts</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="text-sm">📱 "मेरे खेत में क्या दिक्कत है?" (What's wrong with my field?)</div>
                      <div className="text-sm">🌾 Instant crop health photos analysis</div>
                      <div className="text-sm">💰 Cost-optimized treatment recommendations</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </section>

      <Features />
      <Testimonials />
      <Footer />
    </div>
  );
}