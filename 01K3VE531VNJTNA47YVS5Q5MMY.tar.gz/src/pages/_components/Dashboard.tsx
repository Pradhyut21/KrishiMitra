import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Progress } from "@/components/ui/progress.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import { 
  TrendingUp, 
  Droplets, 
  Thermometer, 
  Wind, 
  Sun, 
  AlertTriangle, 
  CheckCircle, 
  Activity,
  MapPin,
  Calendar
} from "lucide-react";

export default function Dashboard() {
  const fieldData = [
    { name: "Block A-1", health: 92, crop: "Wheat", area: "2.3 acres", status: "Healthy" },
    { name: "Block A-2", health: 78, crop: "Mustard", area: "1.8 acres", status: "Moderate" },
    { name: "Block B-1", health: 45, crop: "Wheat", area: "2.1 acres", status: "At Risk" },
  ];

  const weatherData = {
    temperature: 24,
    humidity: 68,
    windSpeed: 12,
    rainfall: 2.3,
    sunshine: 8.2
  };

  const recentAlerts = [
    {
      type: "warning",
      message: "Aphid risk increasing in Block B-1",
      time: "2 hours ago",
      action: "Apply neem-based spray"
    },
    {
      type: "success",
      message: "Irrigation completed successfully",
      time: "1 day ago",
      action: "Monitor soil moisture"
    },
    {
      type: "info",
      message: "Optimal fertilizer window: March 15-17",
      time: "2 days ago",
      action: "Schedule DAP application"
    }
  ];

  const getHealthColor = (health: number) => {
    if (health >= 80) return "text-green-600 bg-green-50";
    if (health >= 60) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Healthy": return "bg-green-100 text-green-800";
      case "Moderate": return "bg-yellow-100 text-yellow-800";
      case "At Risk": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      {/* Farm Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="size-5 text-green-600" />
              Ramesh Uncle's Farm - Meerut, UP
            </CardTitle>
            <CardDescription>
              Total Area: 6.2 acres • Crops: Wheat, Mustard • Season: Rabi 2024
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {fieldData.map((field, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-lg">{field.name}</h3>
                      <Badge className={getStatusColor(field.status)}>
                        {field.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground mb-3">
                      {field.crop} • {field.area}
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Crop Health Score</span>
                        <span className="font-medium">{field.health}%</span>
                      </div>
                      <Progress value={field.health} className="h-2" />
                    </div>
                  </div>
                  <div className={`ml-4 p-3 rounded-full ${getHealthColor(field.health)}`}>
                    <Activity className="size-6" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sun className="size-5 text-yellow-600" />
              Weather Conditions
            </CardTitle>
            <CardDescription>
              Real-time data from IMD • Updated 1 hour ago
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <Thermometer className="size-5 text-blue-600 mx-auto mb-1" />
                <div className="text-2xl font-bold text-blue-800">{weatherData.temperature}°C</div>
                <div className="text-xs text-muted-foreground">Temperature</div>
              </div>
              
              <div className="text-center p-3 bg-cyan-50 rounded-lg">
                <Droplets className="size-5 text-cyan-600 mx-auto mb-1" />
                <div className="text-2xl font-bold text-cyan-800">{weatherData.humidity}%</div>
                <div className="text-xs text-muted-foreground">Humidity</div>
              </div>
              
              <div className="text-center p-3 bg-gray-50 rounded-lg">
                <Wind className="size-5 text-gray-600 mx-auto mb-1" />
                <div className="text-2xl font-bold text-gray-800">{weatherData.windSpeed}</div>
                <div className="text-xs text-muted-foreground">km/h Wind</div>
              </div>
              
              <div className="text-center p-3 bg-indigo-50 rounded-lg">
                <Sun className="size-5 text-indigo-600 mx-auto mb-1" />
                <div className="text-2xl font-bold text-indigo-800">{weatherData.sunshine}h</div>
                <div className="text-xs text-muted-foreground">Sunshine</div>
              </div>
            </div>
            
            <Separator />
            
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-sm text-muted-foreground mb-1">7-day Rainfall</div>
              <div className="text-xl font-bold text-green-800">{weatherData.rainfall} mm</div>
              <div className="text-xs text-green-600">Optimal for crop growth</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts and Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="size-5 text-amber-600" />
              Recent Alerts
            </CardTitle>
            <CardDescription>
              AI-generated insights and recommendations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentAlerts.map((alert, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-lg border">
                  <div className={`p-1 rounded-full ${
                    alert.type === 'warning' ? 'bg-amber-100' :
                    alert.type === 'success' ? 'bg-green-100' : 'bg-blue-100'
                  }`}>
                    {alert.type === 'warning' && <AlertTriangle className="size-4 text-amber-600" />}
                    {alert.type === 'success' && <CheckCircle className="size-4 text-green-600" />}
                    {alert.type === 'info' && <Calendar className="size-4 text-blue-600" />}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-sm mb-1">{alert.message}</p>
                    <p className="text-xs text-muted-foreground mb-2">{alert.time}</p>
                    <p className="text-xs text-green-700 font-medium">💡 {alert.action}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="size-5 text-green-600" />
              Yield Predictions
            </CardTitle>
            <CardDescription>
              AI-powered harvest forecasting
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold text-green-800">Wheat (4.4 acres)</span>
                  <Badge className="bg-green-100 text-green-800">High Confidence</Badge>
                </div>
                <div className="text-2xl font-bold text-green-600 mb-1">18.5 tons</div>
                <div className="text-sm text-muted-foreground">Expected harvest: April 15-25</div>
                <div className="text-sm text-green-700 mt-2">📈 +15% vs last year</div>
              </div>
              
              <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold text-yellow-800">Mustard (1.8 acres)</span>
                  <Badge className="bg-yellow-100 text-yellow-800">Medium Risk</Badge>
                </div>
                <div className="text-2xl font-bold text-yellow-600 mb-1">2.3 tons</div>
                <div className="text-sm text-muted-foreground">Expected harvest: March 20-30</div>
                <div className="text-sm text-yellow-700 mt-2">⚠️ Monitor aphid levels</div>
              </div>
            </div>
            
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-sm text-muted-foreground mb-1">Total Expected Revenue</div>
              <div className="text-2xl font-bold text-blue-600">₹4,85,000</div>
              <div className="text-sm text-blue-700">+₹65,000 vs predicted baseline</div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}