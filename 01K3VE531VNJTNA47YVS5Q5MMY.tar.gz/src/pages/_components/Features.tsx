import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { 
  Satellite, 
  Smartphone, 
  Brain, 
  Users, 
  TrendingUp, 
  Shield, 
  MapPin, 
  MessageCircle,
  Camera,
  Globe,
  Zap,
  Heart
} from "lucide-react";

export default function Features() {
  const features = [
    {
      icon: Satellite,
      title: "Real-Time Satellite Monitoring",
      description: "Advanced AI analysis of multi-spectral satellite imagery from Sentinel-2, ResourceSAT, and Sentinel-1 for comprehensive crop health assessment.",
      highlights: [
        "10m spatial resolution",
        "All-weather monitoring with SAR",
        "NDVI, NDWI, EVI analysis",
        "Sub-field level insights"
      ],
      color: "bg-blue-50 text-blue-600 border-blue-200"
    },
    {
      icon: Brain,
      title: "AI Disease Detection",
      description: "Cutting-edge machine learning models fine-tuned on Indian agricultural data to detect diseases and pests 2-3 weeks before visible symptoms appear.",
      highlights: [
        "94.7% accuracy rate",
        "15+ crop varieties supported",
        "Early warning system",
        "Regional disease patterns"
      ],
      color: "bg-purple-50 text-purple-600 border-purple-200"
    },
    {
      icon: Smartphone,
      title: "WhatsApp Integration",
      description: "Seamless farmer-friendly interface through WhatsApp with voice commands, instant photo analysis, and treatment recommendations in local languages.",
      highlights: [
        "12 Indian languages",
        "Voice-based queries",
        "Instant photo analysis",
        "Treatment recommendations"
      ],
      color: "bg-green-50 text-green-600 border-green-200"
    },
    {
      icon: MapPin,
      title: "Precision Field Mapping",
      description: "GPS-accurate field boundaries and problem zone identification down to 10m resolution, perfect for India's fragmented small farms.",
      highlights: [
        "Sub-field monitoring",
        "Boundary detection",
        "Problem zone mapping",
        "Treatment area optimization"
      ],
      color: "bg-amber-50 text-amber-600 border-amber-200"
    },
    {
      icon: Users,
      title: "Community Intelligence",
      description: "Collective learning from thousands of farmers to predict regional disease outbreaks and share best practices from high-performing neighboring farms.",
      highlights: [
        "Regional outbreak alerts",
        "Best practice sharing",
        "Peer comparison",
        "Collective intelligence"
      ],
      color: "bg-cyan-50 text-cyan-600 border-cyan-200"
    },
    {
      icon: TrendingUp,
      title: "Market Integration",
      description: "Real-time market prices, optimal harvesting timing, and direct connection with agri-input dealers for seamless product procurement.",
      highlights: [
        "Market price alerts",
        "Harvest timing optimization",
        "Dealer network integration",
        "Supply chain connectivity"
      ],
      color: "bg-emerald-50 text-emerald-600 border-emerald-200"
    }
  ];

  const technicalSpecs = [
    { label: "Satellite Data Sources", value: "4+ providers", icon: Satellite },
    { label: "Crop Varieties", value: "15+", icon: Camera },
    { label: "Languages Supported", value: "12", icon: Globe },
    { label: "Detection Accuracy", value: "94.7%", icon: Zap },
    { label: "Early Warning", value: "2-3 weeks", icon: Shield },
    { label: "Active Farmers", value: "10,000+", icon: Heart }
  ];

  return (
    <section className="py-16 px-4 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge className="bg-green-100 text-green-800 mb-4">
            Advanced Technology Stack
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Comprehensive AI-Powered Features
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            KrishiMitra combines cutting-edge geospatial AI, satellite technology, and farmer-centric design 
            to deliver precision agriculture solutions tailored for India's unique farming landscape.
          </p>
        </div>

        {/* Technical Specifications */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-16">
          {technicalSpecs.map((spec, index) => (
            <Card key={index} className="text-center p-4 border-2 hover:shadow-lg transition-all">
              <CardContent className="p-2">
                <spec.icon className="size-6 text-blue-600 mx-auto mb-2" />
                <div className="text-lg font-bold text-foreground">{spec.value}</div>
                <div className="text-xs text-muted-foreground">{spec.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className={`relative overflow-hidden border-2 ${feature.color} hover:shadow-xl transition-all duration-300 group`}>
              <CardHeader className="pb-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className={`p-3 rounded-lg ${feature.color}`}>
                    <feature.icon className="size-6" />
                  </div>
                  <div>
                    <CardTitle className="text-lg text-foreground group-hover:text-primary transition-colors">
                      {feature.title}
                    </CardTitle>
                  </div>
                </div>
                <CardDescription className="text-sm leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="space-y-2">
                  {feature.highlights.map((highlight, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <div className="size-1.5 bg-current rounded-full opacity-60" />
                      <span className="text-muted-foreground">{highlight}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Technology Stack */}
        <div className="mt-16 p-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-3">
              Built with Enterprise-Grade Technology
            </h3>
            <p className="text-muted-foreground">
              Powered by IBM watsonx.ai, Red Hat OpenShift, and cutting-edge geospatial AI models
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="space-y-2">
              <div className="text-lg font-semibold text-blue-600">AI/ML</div>
              <div className="text-sm text-muted-foreground space-y-1">
                <div>IBM watsonx.ai</div>
                <div>PyTorch</div>
                <div>Geospatial Foundation Models</div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-lg font-semibold text-green-600">Satellite Data</div>
              <div className="text-sm text-muted-foreground space-y-1">
                <div>Sentinel-1/2</div>
                <div>ResourceSAT-2A</div>
                <div>Google Earth Engine</div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-lg font-semibold text-purple-600">Infrastructure</div>
              <div className="text-sm text-muted-foreground space-y-1">
                <div>Red Hat OpenShift</div>
                <div>IBM Cloud</div>
                <div>PostGIS Database</div>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="text-lg font-semibold text-amber-600">Integration</div>
              <div className="text-sm text-muted-foreground space-y-1">
                <div>WhatsApp Business API</div>
                <div>React Native</div>
                <div>Twilio Voice</div>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <Card className="max-w-2xl mx-auto border-2 border-green-200 bg-green-50">
            <CardContent className="p-8">
              <MessageCircle className="size-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-foreground mb-3">
                Experience KrishiMitra Today
              </h3>
              <p className="text-muted-foreground mb-6">
                Join thousands of farmers already using AI-powered precision agriculture to increase yields and reduce costs.
              </p>
              <div className="bg-white px-6 py-3 rounded-lg border inline-block">
                <div className="text-sm text-muted-foreground mb-1">WhatsApp Demo</div>
                <div className="text-lg font-bold text-green-600">+91-98765-43210</div>
                <div className="text-xs text-muted-foreground">Text: "crop health" to start</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}