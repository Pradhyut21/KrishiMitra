import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import { 
  Smartphone, 
  Mail, 
  MapPin, 
  Phone, 
  Satellite, 
  Brain, 
  Users, 
  TrendingUp,
  Globe,
  Github,
  Twitter,
  Linkedin,
  Youtube,
  MessageCircle
} from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { label: "Crop Health Dashboard", href: "#dashboard" },
    { label: "Satellite Monitoring", href: "#satellite" },
    { label: "Smart Alerts", href: "#alerts" },
    { label: "WhatsApp Demo", href: "#whatsapp" },
  ];

  const features = [
    { label: "AI Disease Detection", href: "#ai" },
    { label: "Yield Predictions", href: "#yield" },
    { label: "Weather Integration", href: "#weather" },
    { label: "Market Prices", href: "#market" },
  ];

  const support = [
    { label: "Farmer Support", href: "#support" },
    { label: "Training Videos", href: "#training" },
    { label: "Language Support", href: "#languages" },
    { label: "Technical Help", href: "#help" },
  ];

  const languages = [
    "हिंदी", "ਪੰਜਾਬੀ", "বাংলা", "தமிழ்", "తెలుగు", "ಕನ್ನಡ", 
    "മലയാളം", "ગુજરાતી", "मराठी", "ଓଡ଼ିଆ", "অসমীয়া", "English"
  ];

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="text-2xl">🌾</div>
              <h3 className="text-xl font-bold text-green-400">KrishiMitra</h3>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              AI-powered precision agriculture platform empowering India's small farmers with 
              satellite technology and intelligent crop monitoring.
            </p>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <MapPin className="size-4" />
                <span>Headquartered in Bengaluru, India</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <Users className="size-4" />
                <span>Serving 10,000+ farmers across 5 states</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                <TrendingUp className="size-4" />
                <span>₹15 Cr+ saved in farming costs</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex items-center gap-3 pt-2">
              <Button size="sm" variant="ghost" className="size-8 p-0 text-gray-400 hover:text-white">
                <Twitter className="size-4" />
              </Button>
              <Button size="sm" variant="ghost" className="size-8 p-0 text-gray-400 hover:text-white">
                <Linkedin className="size-4" />
              </Button>
              <Button size="sm" variant="ghost" className="size-8 p-0 text-gray-400 hover:text-white">
                <Youtube className="size-4" />
              </Button>
              <Button size="sm" variant="ghost" className="size-8 p-0 text-gray-400 hover:text-white">
                <Github className="size-4" />
              </Button>
            </div>
          </div>

          {/* Platform Features */}
          <div>
            <h4 className="font-semibold text-lg mb-4 text-green-400">Platform</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-gray-300 hover:text-white text-sm transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>

            <h4 className="font-semibold text-lg mt-6 mb-4 text-blue-400">AI Features</h4>
            <ul className="space-y-3">
              {features.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-gray-300 hover:text-white text-sm transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support & Resources */}
          <div>
            <h4 className="font-semibold text-lg mb-4 text-purple-400">Farmer Support</h4>
            <ul className="space-y-3">
              {support.map((link, index) => (
                <li key={index}>
                  <a href={link.href} className="text-gray-300 hover:text-white text-sm transition-colors">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>

            <div className="mt-6 p-4 bg-gray-800 rounded-lg">
              <h5 className="font-medium mb-2 text-amber-400">WhatsApp Support</h5>
              <div className="flex items-center gap-2 text-sm text-gray-300 mb-2">
                <MessageCircle className="size-4 text-green-500" />
                <span>+91-98765-43210</span>
              </div>
              <p className="text-xs text-gray-400">
                24/7 farmer support in 12 Indian languages
              </p>
            </div>
          </div>

          {/* Contact & Newsletter */}
          <div>
            <h4 className="font-semibold text-lg mb-4 text-cyan-400">Stay Connected</h4>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Mail className="size-4" />
                <span>farmers@krishimitra.in</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Phone className="size-4" />
                <span>1800-KRISHI (1800-574744)</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-300">
                <Globe className="size-4" />
                <span>www.krishimitra.in</span>
              </div>
            </div>

            <div className="space-y-3">
              <h5 className="font-medium text-sm">Get Crop Health Updates</h5>
              <div className="flex gap-2">
                <Input 
                  type="email" 
                  placeholder="Enter mobile number" 
                  className="bg-gray-800 border-gray-700 text-white text-sm"
                />
                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                  Subscribe
                </Button>
              </div>
              <p className="text-xs text-gray-400">
                Weekly crop insights and weather alerts
              </p>
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Language Support Section */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="text-center mb-4">
          <h4 className="font-medium text-sm text-gray-400 mb-3">
            Supported Languages (समर्थित भाषाएं)
          </h4>
          <div className="flex flex-wrap justify-center gap-2 text-xs">
            {languages.map((lang, index) => (
              <span key={index} className="bg-gray-800 px-2 py-1 rounded text-gray-300">
                {lang}
              </span>
            ))}
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Technology Stack */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="text-center">
          <p className="text-xs text-gray-400 mb-3">Powered by</p>
          <div className="flex flex-wrap justify-center items-center gap-6 text-xs text-gray-500">
            <div className="flex items-center gap-1">
              <Brain className="size-3" />
              <span>IBM watsonx.ai</span>
            </div>
            <div className="flex items-center gap-1">
              <Satellite className="size-3" />
              <span>Google Earth Engine</span>
            </div>
            <div>Red Hat OpenShift</div>
            <div>Sentinel-2 Satellite</div>
            <div>ISRO ResourceSAT</div>
            <div>WhatsApp Business API</div>
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Bottom Footer */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
          <div className="flex items-center gap-4">
            <span>© {currentYear} KrishiMitra. All rights reserved.</span>
            <span>•</span>
            <span>Made with ❤️ for Indian farmers</span>
          </div>
          
          <div className="flex items-center gap-4">
            <a href="#privacy" className="hover:text-white transition-colors">Privacy Policy</a>
            <span>•</span>
            <a href="#terms" className="hover:text-white transition-colors">Terms of Service</a>
            <span>•</span>
            <a href="#support" className="hover:text-white transition-colors">Farmer Support</a>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-gray-700 text-center">
          <p className="text-xs text-gray-500">
            Supporting UN Sustainable Development Goals: Zero Hunger, Climate Action, and Responsible Innovation
          </p>
          <p className="text-xs text-gray-500 mt-1">
            "Technology should empower the powerless. KrishiMitra gives India's small farmers the same precision agriculture tools that were previously available only to industrial farming corporations."
          </p>
        </div>
      </div>
    </footer>
  );
}