import { Button } from "@/components/ui/button.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Satellite, Smartphone, TrendingUp, PlayCircle, Star, MapPin } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50" />
      
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 text-6xl">🌾</div>
        <div className="absolute top-40 right-20 text-4xl">🛰️</div>
        <div className="absolute bottom-40 left-20 text-5xl">📱</div>
        <div className="absolute bottom-20 right-10 text-4xl">📊</div>
        <div className="absolute top-60 left-1/2 text-3xl">🌱</div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-20">
        <div className="text-center space-y-8">
          {/* Badge */}
          <Badge className="bg-green-100 text-green-800 border-green-200 text-sm px-4 py-2">
            <Star className="size-4 mr-2" />
            AI-Powered Precision Agriculture for India
          </Badge>

          {/* Main Heading */}
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-balance text-foreground leading-tight">
            🌾 <span className="text-green-600">KrishiMitra</span>
            <br />
            <span className="text-3xl md:text-4xl lg:text-5xl text-muted-foreground">
              Your AI Farm Assistant
            </span>
          </h1>

          {/* Description */}
          <p className="text-xl md:text-2xl text-muted-foreground max-w-4xl mx-auto text-balance leading-relaxed">
            Transform your farming with <span className="font-semibold text-green-700">satellite AI technology</span> designed for India's small farmers. 
            Get <span className="font-semibold text-blue-700">crop health insights</span>, 
            <span className="font-semibold text-purple-700"> early disease detection</span>, and 
            <span className="font-semibold text-amber-700"> precision recommendations</span> directly on WhatsApp.
          </p>

          {/* Key Stats */}
          <div className="flex flex-wrap justify-center gap-6 text-center py-4">
            <div className="bg-white/80 backdrop-blur-sm rounded-lg px-6 py-3 shadow-sm border">
              <div className="text-2xl font-bold text-green-600">94.7%</div>
              <div className="text-sm text-muted-foreground">Disease Detection Accuracy</div>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-lg px-6 py-3 shadow-sm border">
              <div className="text-2xl font-bold text-blue-600">₹15,000</div>
              <div className="text-sm text-muted-foreground">Average Savings/Season</div>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-lg px-6 py-3 shadow-sm border">
              <div className="text-2xl font-bold text-purple-600">25%</div>
              <div className="text-sm text-muted-foreground">Yield Improvement</div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 text-lg">
              <Smartphone className="size-5 mr-2" />
              Try WhatsApp Demo
            </Button>
            <Button size="lg" variant="outline" className="px-8 py-4 text-lg border-2">
              <PlayCircle className="size-5 mr-2" />
              Watch Demo Video
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="pt-8 space-y-4">
            <p className="text-sm text-muted-foreground">Trusted by farmers across India</p>
            <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <MapPin className="size-4 text-blue-600" />
                <span>5 States • 10,000+ Farmers</span>
              </div>
              <div className="flex items-center gap-2">
                <Satellite className="size-4 text-purple-600" />
                <span>Real-time Satellite Monitoring</span>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="size-4 text-green-600" />
                <span>12 Indian Languages</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* WhatsApp Badge */}
      <div className="absolute bottom-6 right-6 bg-green-500 text-white px-4 py-2 rounded-full shadow-lg hover:bg-green-600 transition-colors cursor-pointer">
        <div className="flex items-center gap-2 text-sm font-medium">
          <div className="size-2 bg-white rounded-full animate-pulse" />
          WhatsApp: +91-98765-43210
        </div>
      </div>
    </section>
  );
}