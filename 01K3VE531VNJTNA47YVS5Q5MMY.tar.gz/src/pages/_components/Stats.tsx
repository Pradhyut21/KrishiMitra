import { Card, CardContent } from "@/components/ui/card.tsx";
import { TrendingUp, Users, MapPin, Target, DollarSign, Zap } from "lucide-react";

export default function Stats() {
  const stats = [
    {
      icon: TrendingUp,
      value: "₹92,000 Cr",
      label: "Annual crop losses in India",
      description: "Due to diseases and pests",
      color: "text-red-600"
    },
    {
      icon: Users,
      value: "146M",
      label: "Small farmers in India",
      description: "With fragmented 2-3 acre plots",
      color: "text-blue-600"
    },
    {
      icon: MapPin,
      value: "1.08 Ha",
      label: "Average farm size",
      description: "Highly fragmented fields",
      color: "text-purple-600"
    },
    {
      icon: Target,
      value: "94.7%",
      label: "AI accuracy achieved",
      description: "Disease detection precision",
      color: "text-green-600"
    },
    {
      icon: DollarSign,
      value: "40-60%",
      label: "Input cost savings",
      description: "Through precision application",
      color: "text-amber-600"
    },
    {
      icon: Zap,
      value: "2-3 Weeks",
      label: "Early warning period",
      description: "Before visible symptoms",
      color: "text-cyan-600"
    }
  ];

  return (
    <section className="py-16 px-4 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            The Agricultural Challenge in India
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            India's farmers face unprecedented challenges with crop diseases, fragmented farms, and limited access to precision agriculture technology.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stats.map((stat, index) => (
            <Card key={index} className="relative overflow-hidden group hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-lg bg-opacity-10 ${stat.color.replace('text-', 'bg-')}`}>
                    <stat.icon className={`size-6 ${stat.color}`} />
                  </div>
                  <div className="flex-1">
                    <div className="text-2xl font-bold text-foreground mb-1">
                      {stat.value}
                    </div>
                    <div className="font-semibold text-foreground mb-1">
                      {stat.label}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {stat.description}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12 p-8 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl border">
          <h3 className="text-2xl font-bold text-foreground mb-3">
            KrishiMitra bridges this gap with AI-powered precision agriculture
          </h3>
          <p className="text-lg text-muted-foreground mb-4">
            Bringing enterprise-grade crop monitoring to every small farmer in India through satellite technology and WhatsApp integration.
          </p>
          <div className="flex items-center justify-center gap-8 text-sm text-muted-foreground">
            <div>🛰️ Real-time monitoring</div>
            <div>🤖 AI disease detection</div>
            <div>📱 WhatsApp alerts</div>
            <div>🌾 Precision recommendations</div>
          </div>
        </div>
      </div>
    </section>
  );
}