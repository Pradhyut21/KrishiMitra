import { Card, CardContent } from "@/components/ui/card.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar.tsx";
import { Star, MapPin, TrendingUp, DollarSign, Quote } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      name: "Ramesh Kumar",
      location: "Meerut, Uttar Pradesh", 
      crop: "Wheat & Mustard",
      area: "6.2 acres",
      savings: "₹18,000",
      yieldIncrease: "22%",
      quote: "KrishiMitra saved my mustard crop! The AI detected aphid infestation 3 weeks before I could see it. The WhatsApp alerts in Hindi made everything so simple to understand.",
      hindi: "कृषिमित्र ने मेरी सरसों की फसल बचाई! AI ने माहू का संक्रमण 3 हफ्ते पहले ही पकड़ लिया था। हिंदी में व्हाट्सऐप अलर्ट्स समझने में बहुत आसान थे।",
      avatar: "RK",
      rating: 5,
      before: "Lost 60% of crop to diseases",
      after: "Early detection & prevention"
    },
    {
      name: "Harpreet Singh",
      location: "Ludhiana, Punjab",
      crop: "Rice & Wheat",
      area: "8.5 acres", 
      savings: "₹25,000",
      yieldIncrease: "18%",
      quote: "The satellite monitoring is incredible! I can see my entire farm health from my phone. The fertilizer recommendations saved me thousands in input costs.",
      punjabi: "ਸੈਟੇਲਾਈਟ ਨਿਗਰਾਨੀ ਸ਼ਾਨਦਾਰ ਹੈ! ਮੈਂ ਆਪਣੇ ਫੋਨ ਤੋਂ ਪੂਰੇ ਖੇਤ ਦੀ ਸਿਹਤ ਦੇਖ ਸਕਦਾ ਹਾਂ। ਖਾਦ ਦੀਆਂ ਸਿਫਾਰਸ਼ਾਂ ਨੇ ਹਜ਼ਾਰਾਂ ਰੁਪਏ ਬਚਾਏ।",
      avatar: "HS",
      rating: 5,
      before: "Overuse of fertilizers",
      after: "Precision application"
    },
    {
      name: "Priya Patel",
      location: "Anand, Gujarat",
      crop: "Cotton",
      area: "4.3 acres",
      savings: "₹12,000",
      yieldIncrease: "28%",
      quote: "As a woman farmer, technology seemed intimidating. But KrishiMitra's voice commands in Gujarati made it so easy. My cotton yield increased by 28% this season!",
      gujarati: "મહિલા ખેડૂત તરીકે, ટેકનોલોજી ડરામણી લાગતી હતી. પણ કૃષિમિત્રના ગુજરાતી વૉઇસ કમાન્ડ્સે તેને આટલું સહેલું બનાવ્યું. આ સિઝનમાં મારા કપાસના ઉત્પાદનમાં ૨૮% વધારો થયો!",
      avatar: "PP",
      rating: 5,
      before: "Traditional farming methods",
      after: "Technology-enabled precision"
    },
    {
      name: "Mohammed Ansari",
      location: "Nashik, Maharashtra",
      crop: "Sugarcane",
      area: "12.1 acres",
      savings: "₹45,000",
      yieldIncrease: "35%",
      quote: "The disease prediction accuracy is amazing! KrishiMitra predicted red rot in my sugarcane fields and gave me exact GPS coordinates for treatment. Saved my entire harvest.",
      hindi: "बीमारी की भविष्यवाणी की सटीकता अद्भुत है! कृषिमित्र ने मेरे गन्ने के खेतों में लाल सड़न की भविष्यवाणी की और इलाज के लिए सटीक GPS निर्देशांक दिए। पूरी फसल बच गई।",
      avatar: "MA",
      rating: 5,
      before: "Entire harvest at risk",
      after: "Precise intervention & recovery"
    },
    {
      name: "Dr. Rajesh Sharma",
      location: "Agriculture Extension Officer, UP",
      crop: "Department Official",
      area: "Supporting 500+ farmers",
      savings: "₹2.5L+ collective",
      yieldIncrease: "Average 24%",
      quote: "KrishiMitra has revolutionized how we support farmers. The AI insights help us make data-driven decisions and the multilingual interface breaks down technology barriers.",
      hindi: "कृषिमित्र ने किसानों की सहायता के तरीके में क्रांति ला दी है। AI अंतर्दृष्टि डेटा-संचालित निर्णय लेने में मदद करती है और बहुभाषी इंटरफेस तकनीकी बाधाओं को तोड़ता है।",
      avatar: "RS",
      rating: 5,
      before: "Manual monitoring challenges",
      after: "Scalable tech-enabled support"
    },
    {
      name: "Kiran Devi",
      location: "Jaipur, Rajasthan",
      crop: "Mustard & Barley",
      area: "3.8 acres",
      savings: "₹14,500",
      yieldIncrease: "31%",
      quote: "The community feature is fantastic! I learned about a new organic pest control method from a farmer 50km away who had similar issues. KrishiMitra connects us all.",
      hindi: "कम्युनिटी फीचर शानदार है! मैंने 50 किमी दूर के एक किसान से नया जैविक कीट नियंत्रण तरीका सीखा जिसकी समस्या मेरे जैसी थी। कृषिमित्र हम सभी को जोड़ता है।",
      avatar: "KD",
      rating: 5,
      before: "Isolated farming practices",
      after: "Connected farming community"
    }
  ];

  const impactStats = [
    { label: "Active Farmers", value: "10,000+", color: "text-green-600" },
    { label: "Total Savings", value: "₹15 Cr+", color: "text-blue-600" },
    { label: "Avg. Yield Increase", value: "25%", color: "text-purple-600" },
    { label: "Diseases Prevented", value: "50,000+", color: "text-amber-600" }
  ];

  return (
    <section className="py-16 px-4 bg-gradient-to-b from-white to-green-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge className="bg-green-100 text-green-800 mb-4">
            Real Impact Stories
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Transforming Lives Across India
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From small farmers to agricultural extension officers, see how KrishiMitra is revolutionizing 
            precision agriculture and improving livelihoods across rural India.
          </p>
        </div>

        {/* Impact Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {impactStats.map((stat, index) => (
            <Card key={index} className="text-center p-6 bg-white shadow-sm border-2">
              <div className={`text-3xl font-bold ${stat.color} mb-2`}>
                {stat.value}
              </div>
              <div className="text-sm text-muted-foreground">
                {stat.label}
              </div>
            </Card>
          ))}
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="relative overflow-hidden hover:shadow-lg transition-all duration-300 border-2">
              <CardContent className="p-6">
                {/* Header */}
                <div className="flex items-start gap-4 mb-4">
                  <Avatar className="size-12 border-2 border-green-200">
                    <AvatarImage src="" />
                    <AvatarFallback className="bg-green-100 text-green-700 font-bold">
                      {testimonial.avatar}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-lg text-foreground">
                        {testimonial.name}
                      </h3>
                      <div className="flex items-center gap-1">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="size-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mb-2">
                      <MapPin className="size-3" />
                      {testimonial.location}
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary" className="text-xs">
                        {testimonial.crop}
                      </Badge>
                      <Badge variant="secondary" className="text-xs">
                        {testimonial.area}
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Quote */}
                <div className="relative mb-4">
                  <Quote className="size-6 text-gray-300 absolute -top-2 -left-2" />
                  <p className="text-sm text-muted-foreground leading-relaxed pl-4 italic">
                    "{testimonial.quote}"
                  </p>
                  {(testimonial.hindi || testimonial.punjabi || testimonial.gujarati) && (
                    <p className="text-xs text-muted-foreground mt-2 pl-4 opacity-70">
                      {testimonial.hindi || testimonial.punjabi || testimonial.gujarati}
                    </p>
                  )}
                </div>

                {/* Results */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <DollarSign className="size-4 text-green-600" />
                      <span className="font-bold text-green-600">{testimonial.savings}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">Saved per season</div>
                  </div>
                  
                  <div className="text-center">
                    <div className="flex items-center justify-center gap-1 mb-1">
                      <TrendingUp className="size-4 text-blue-600" />
                      <span className="font-bold text-blue-600">{testimonial.yieldIncrease}</span>
                    </div>
                    <div className="text-xs text-muted-foreground">Yield increase</div>
                  </div>
                </div>

                {/* Before/After */}
                <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <div className="text-red-600 font-medium mb-1">Before KrishiMitra:</div>
                      <div className="text-muted-foreground">{testimonial.before}</div>
                    </div>
                    <div>
                      <div className="text-green-600 font-medium mb-1">After KrishiMitra:</div>
                      <div className="text-muted-foreground">{testimonial.after}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-8 rounded-xl">
            <h3 className="text-2xl font-bold mb-3">
              Join the KrishiMitra Revolution
            </h3>
            <p className="text-lg opacity-90 mb-6 max-w-2xl mx-auto">
              Experience the same transformation as thousands of farmers across India. 
              Start your precision agriculture journey today.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg px-6 py-3">
                <div className="text-sm opacity-80">WhatsApp Demo</div>
                <div className="text-xl font-bold">+91-98765-43210</div>
              </div>
              <div className="text-sm opacity-80">
                Text "मेरे खेत की जांच करो" to get started
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}